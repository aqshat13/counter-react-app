// import logo from './logo.svg';
import './App.css';
import{useState} from 'react';

function App() {
  // let number=0;
  const [number,setNumber]=useState(0);
  
  const appName='A Counter App.';
  <button>🔃</button>;


  const increase=()=>{
    setNumber(number+1);
  };
  const decrease=()=>{
     setNumber(number-1);
  };
  
  return (
    <div class="container">
      <h1>{appName}</h1>
      <div>

        <h2><span>count-{number}</span></h2>
        
        </div>
        <div>

          <button onClick={decrease}>🔽</button>
          <button onClick={increase}>🔼</button>
        </div>

    </div>
  );
}

export default App;
